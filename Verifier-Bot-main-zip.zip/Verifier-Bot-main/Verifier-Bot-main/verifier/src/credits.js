/*
 * ============================================================
 *   Verifier Bot
 *  Made by: Ayle
 *  All Rights Reserved ©  Development
 *  Support: https://discord.gg/
 * ============================================================
 *
 * WARNING: This file is integrity-protected.
 * Altering AUTHOR_CREDITS will prevent the bot from starting.
 * ============================================================
 */

const AUTHOR_CREDITS = " Verifier Bot | Made by Ayle | All rights reserved \u00A9  Development | https://discord.gg/";

module.exports = { AUTHOR_CREDITS };
